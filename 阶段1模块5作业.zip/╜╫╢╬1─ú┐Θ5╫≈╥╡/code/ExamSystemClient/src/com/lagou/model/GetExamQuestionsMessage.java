package com.lagou.model;

import java.io.Serializable;
import java.util.HashMap;

public class GetExamQuestionsMessage implements Serializable {
    private static final long serialVersionUID = -6499047479469268830L;
    private String message;
    private HashMap<Integer,ChoiceQuestion> choiceQuestionHashMap;
    public GetExamQuestionsMessage(String message) {
        choiceQuestionHashMap = new HashMap<>();
        this.message = message;
    }

    public HashMap<Integer, ChoiceQuestion> getChoiceQuestionHashMap() {
        return choiceQuestionHashMap;
    }

    public void setChoiceQuestionHashMap(HashMap<Integer, ChoiceQuestion> choiceQuestionHashMap) {
        this.choiceQuestionHashMap = choiceQuestionHashMap;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
