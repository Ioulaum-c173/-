package com.lagou.model;

import java.io.Serializable;

public class ChoiceQuestion implements Serializable {
    private static final long serialVersionUID = 2568056085231565296L;
    private String question;
    private String choices;
    private String answer;

    public ChoiceQuestion(String question,String choices, String answer) {
        this.question = question;
        this.choices = choices;
        this.answer = answer;
    }

    public String getQuestion() {
        return question;
    }

    public void setQuestion(String question) {
        this.question = question;
    }

    public String getChoices() {
        return choices;
    }

    public void setChoices(String choices) {
        this.choices = choices;
    }

    public String getAnswer() {
        return answer;
    }

    public void setAnswer(String answer) {
        this.answer = answer;
    }

    @Override
    public String toString() {
        return "ChoiceQuestion{" +
                "question='" + question + '\'' +
                ", choices='" + choices + '\'' +
                ", answer='" + answer + '\'' +
                '}';
    }

    /**
     * 管理员在通过序号查询问题内容时调用
     */
    public void show() {
        System.out.println("问题： " + question);
        System.out.println("选择： " + choices);
        System.out.println("答案： " + answer);
        System.out.println("----------------------------");
        System.out.println();
    }

    /**
     * 考试时用来打印问题
     */
    public void examPrint(){
        System.out.println(question);
        System.out.println(choices);
        System.out.println("请输入答案：");
    }
}
