package com.lagou.client;

import com.lagou.model.*;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * 编程实现客户端的主界面绘制和相应功能的实现
 */
public class ClientView {
    /**
     * 为了可以使用输入输出流，采用合成复用原则实现
     */
    private ClientInitClose cic;
    private ArrayList<Grands> grandsArrayList = new ArrayList<>();


    /**
     * 通过构造方法实现成员变量的初始化
     * @param cic
     */
    public ClientView(ClientInitClose cic) {
        this.cic = cic;
    }

    /**
     * 自定义成员方法实现客户端主界面的绘制
     */
    public void clientMainPage() throws IOException, ClassNotFoundException {
        boolean flag = true;
        while(flag) {
            System.out.println("  \n\n\t\t   在线考试系统");
            System.out.println("-------------------------------------------");
            System.out.print("   [1] 学员系统");
            System.out.println("     [2] 管理员系统");
            System.out.println("   [0] 退出系统");
            System.out.println("-------------------------------------------");
            System.out.println("请选择要进行的业务编号：");
            int choose = ClientScanner.getScanner().nextInt();
            switch (choose) {
                case 0:
                    System.out.println("正在退出系统...");
                    clientLogout();
                    flag = false;
                    break;
                case 1:
                    System.out.println("正在进入学员系统...");
                    clientLogin();
                    break;
                case 2:
                    System.out.println("正在进入管理员系统");
                    clientManagerLogin();
                    break;
                default:
                    System.out.println("输入错误，请重新选择！");
            }
        }
    }

    private void clientLogout() throws IOException {
        UserMessage userMessage = new UserMessage("Logout",null);
        cic.getOos().writeObject(userMessage);
    }

    /**
     * 自定义成员方法实现客户端管理员登录的功能
     */
    private void clientManagerLogin() throws IOException, ClassNotFoundException {
        // 1.准备管理员登录的相关数据
        System.out.println("请输入管理员的账户信息：");
        String userName = ClientScanner.getScanner().next();
        System.out.println("请输入管理员的密码信息：");
        String password = ClientScanner.getScanner().next();
        UserMessage tum = new UserMessage("managerCheck", new User(userName, password));
        // 2.将UserMessage类型的对象通过对象输出流发送给服务器
        cic.getOos().writeObject(tum);
        System.out.println("客户端发送管理员账户信息成功！");
        // 3.接收服务器的处理结果并给出提示
        tum = (UserMessage) cic.getOis().readObject();
        if ("success".equals(tum.getType())) {
            System.out.println("登录成功，欢迎使用！");
            //如果登录成功显示管理员系统的功能界面
            clientManagerFunction();
        } else {
            System.out.println("用户名或密码错误！");
        }
    }

    private void clientLogin() throws IOException, ClassNotFoundException {
        Object o;
        System.out.println("请输入学号");
        long studentNum = ClientScanner.getScanner().nextLong();
        String userName = "" + studentNum;
        System.out.println("请输入密码");
        String password = ClientScanner.getScanner().next();
        UserMessage userMessage = new UserMessage("userCheck",new User(userName,password));
        cic.getOos().writeObject(userMessage);
        userMessage = (UserMessage) cic.getOis().readObject();
        if ("success".equals(userMessage.getType())){
            System.out.println("登录成功，欢迎使用！");
            //如果登录成功显示管理员系统的功能界面
            clientStudentFunction(studentNum);
        }else {
            System.out.println("用户名(学号)或密码错误！");
        }
    }

    private void clientStudentFunction(long studentNum) throws IOException, ClassNotFoundException {
        int choose;
        boolean flag = true;
        while (flag) {
            System.out.println("\t\t在线考试系统学员界面");
            System.out.println("-------------------------------------------");
            System.out.print("   [1] 开始考试");
            System.out.print("   [2] 查询成绩");
            System.out.println("   [3] 修改密码");
            System.out.println("   [0] 退出考试系统");
            System.out.println("请选择要进行的业务编号：");
            choose = ClientScanner.getScanner().nextInt();
            switch (choose){
                case 0:
                    flag = false;
                    break;
                case 1:
                    startExam(studentNum);
                    break;
                case 2:
                    getGrands();
                    break;
                case 3:
                    updatePassword(studentNum);
                    break;
                default:
                    System.out.println("输入的编号不正确");
                    break;
            }
        }
    }

    private void updatePassword(long studentNum) throws IOException, ClassNotFoundException {
        System.out.println("请输入原密码");
        String password =  ClientScanner.getScanner().next();
        //构造OperationStudentMessage类型的对象将其写入对象输出流中
        OperationStudentMessage operation = new OperationStudentMessage
                (studentNum,OperationStudentMessage.QUERY);
        cic.getOos().writeObject(operation);
        Object o = cic.getOis().readObject();
        if (o.getClass() == OperationStudentMessage.class){
            operation = (OperationStudentMessage)o;
            if ("success".equals(operation.getResult()) && null != operation.getStudent()){
                Student student = operation.getStudent();
                if (password.equals(student.getPassword())){
                    System.out.println("验证成功！");
                    System.out.println("请输入新密码");
                    String newPassword = ClientScanner.getScanner().next();
                    Student newStudent = new Student(student.getStudentNum(),student.getStudentName(),
                            student.getStudentGender(),student.getStudentAge(),newPassword);
                    //将新增的Student类型的对象发送给服务器端
                    operation = new OperationStudentMessage(newStudent.getStudentNum(),
                            OperationStudentMessage.UPDATE,newStudent);
                    cic.getOos().writeObject(operation);
                    operation = (OperationStudentMessage) cic.getOis().readObject();
                    if("success".equals(operation.getResult())){
                        System.out.println("密码修改成功");
                    }
                }else {
                    System.out.println("原密码不符，请重新输入！");
                }
            }
        }
    }

    /**
     * 该方法负责考题的选取和打印以及最终的成绩的判定和存储
     * @param studentNum
     */
    private void startExam(long studentNum) throws IOException, ClassNotFoundException {
        System.out.println("----------开始考试----------");
        //将GetExamQuestionsMessage传给服务器端，从服务器端获取考题的HashMap集合
        GetExamQuestionsMessage examMessage = new GetExamQuestionsMessage("getQuestions");
        cic.getOos().writeObject(examMessage);
        examMessage = (GetExamQuestionsMessage)cic.getOis().readObject();
        if ("success".equals(examMessage.getMessage())){
            HashMap<Integer,ChoiceQuestion> examQuestions = examMessage.getChoiceQuestionHashMap();
            Iterator iter = examQuestions.entrySet().iterator();
            Integer key;
            ChoiceQuestion value;
            int rightAnswer = 0;
            //遍历获得的考题，并让学员输入答案判断答案是否正确
            while(iter.hasNext()) {
                int num = 1;
                Map.Entry entry = (Map.Entry) iter.next();
                key = (Integer) entry.getKey();
                value = (ChoiceQuestion) entry.getValue();
                System.out.println(num+"."+"(题目序号:"+key+")");
                num++;
                value.examPrint();
                //判断输入的答案是否正确
                if (value.getAnswer().equalsIgnoreCase(ClientScanner.getScanner().next())){
                    rightAnswer++;
                }
            }
            System.out.println("考试结束，总分为：" + 10*examQuestions.size()
                    + "\n您获得的分数为"+ rightAnswer * 10);
            //将成绩录入本地集合
            int totalGrand = 10 * examQuestions.size();
            double grand = 10 * rightAnswer;
            DateFormat df = new SimpleDateFormat("yyyy_MM_dd_HH:mm:ss");
            Calendar calendar = Calendar.getInstance();
            String dateName = df.format(calendar.getTime());
            grandsArrayList.add(new Grands(studentNum,totalGrand,grand,dateName));
        }else {
            System.out.println("读取考题失败");
        }
}


    /**
     * 打印所有的成绩信息
     */
    private void getGrands() {
        //遍历grandsArrayList中的grands对象，获取所有成绩信息
        for (Grands grands:grandsArrayList) {
            System.out.println(grands.show());
        }
    }

    private void clientManagerFunction() throws IOException, ClassNotFoundException {
        boolean flag = true;
        while(flag){
            //打印系统的功能列表
            System.out.println("\t\t在线考试系统管理员界面");
            System.out.println("-------------------------------------------");
            System.out.print("   [1] 学员管理系统");
            System.out.println("   [2] 考题管理系统");
            System.out.println("   [0] 退出管理员系统");
            System.out.println("-------------------------------------------");
            System.out.println("请选择要进行的业务编号：");
            int choose = ClientScanner.getScanner().nextInt();
            switch (choose){
                case 1:
                    studentManage();
                    break;
                case 2:
                    manageExamQuestion();
                    break;
                case 0:
                    flag = false;
                    break;
            }
        }
    }

    /**
     * 打印学员管理的界面
     */
    private void studentManage() throws IOException, ClassNotFoundException {
        int choose;
        long studentNum = 0;
        String studentName;
        String studentGender = "male";
        int studentAge = 0;
        String password;
        OperationStudentMessage operation;
        Object o;
        HashMap<Long,Student> studentHashMap;
        //打印功能列表
        boolean flag = true;
        while (flag){
            System.out.println("\t\t在线考试系统学员管理");
            System.out.println("-------------------------------------------");
            System.out.print("   [1] 新增学员");
            System.out.print("   [2] 删除学员");
            System.out.print("   [3] 修改学员");
            System.out.print("   [4] 查找学员");
            System.out.print("   [5] 显示所有学员信息");
            System.out.println("   [0] 退出子系统");
            System.out.println("-------------------------------------------");
            System.out.println("请选择要进行的业务编号：");
            choose = ClientScanner.getScanner().nextInt();
            switch (choose){
                case 0:
                    System.out.println("正在退出学员管理子系统......");
                    flag = false;
                    break;
                case 1:
                    System.out.println("-------新增学员-------");
                    System.out.println("请输入新学员的学号(学号也是登录用的用户名！)");
                    studentNum = ClientScanner.getScanner().nextLong();
                    if (queryStudentPrint(studentNum)){
                        System.out.println("该学号已存在，请不要重复添加相同学号的学员");
                        break;
                    }
                    System.out.println("请输入学员姓名：");
                    studentName = ClientScanner.getScanner().next();
                    while (true) {
                        System.out.println("请输入学员性别：男性请输入1，女性请输入2");
                        int sex = ClientScanner.getScanner().nextInt();
                        if (sex == 1){
                            studentGender = "male";
                            break;
                        }else if (sex == 2){
                            studentGender = "female";
                            break;
                        }else {
                            System.out.println("输入的性别不合法！请重新输入");
                        }

                    }
                    //获取年龄信息，并判断是否合理
                    while(true){
                        System.out.println("请输入学员年龄");
                        studentAge = ClientScanner.getScanner().nextInt();
                        if (studentAge >= 0 && studentAge <= 140){
                            break;
                        } else {
                            System.out.println("输入年龄信息不合理，请重新输入");
                        }
                    }
                    //获取密码
                    while (true) {
                        System.out.println("请输入密码：");
                        password = ClientScanner.getScanner().next();
                        if (null != password){
                            break;
                        }else {
                            System.out.println("输入的密码为空，请重新输入！");
                        }
                    }
                    Student newStudent = new Student(studentNum,studentName,studentGender,studentAge,password);
                    //将新增的Student类型的对象发送给服务器端
                    operation = new OperationStudentMessage(newStudent.getStudentNum(),
                            OperationStudentMessage.ADD,newStudent);
                    cic.getOos().writeObject(operation);
                    o = cic.getOis().readObject();
                    if (o.getClass() == OperationStudentMessage.class){
                        operation = (OperationStudentMessage) o;
                        if ("success".equals(operation.getResult())){
                            System.out.println("添加成功！");
                        }else {
                            System.out.println("添加失败！");
                        }
                    }
                    break;

                case 2:
                    while (true) {
                        System.out.println("请输入要删除的用户的学号，退出请输入-1：");
                        studentNum = ClientScanner.getScanner().nextLong();
                        if(studentNum == -1){
                            break;
                        }
                        //向服务器发送消息，删除对应学号的用户
                        operation = new OperationStudentMessage(studentNum,
                                OperationStudentMessage.DELETE);
                        cic.getOos().writeObject(operation);
                        //接收从服务器端传回的消息
                        o = cic.getOis().readObject();
                        //如果传过来的消息不为空，则通过消息结果判断删除操作是否成功
                        if (null != o){
                            if (o.getClass() == OperationStudentMessage.class){
                                operation = (OperationStudentMessage) o;
                            }else {
                                operation = null;
                            }
                        }
                        //打印删除的结果
                        if (null != operation){
                            if("无此用户".equals(operation.getResult())){
                                System.out.println("该学号的学生不存在，请重新输入");
                            }else if ("success".equals(operation.getResult())){
                                System.out.println("删除成功！");
                                break;
                            }

                        }
                    }
                    break;

                //修改学员信息
                case 3:
                    System.out.println("-------修改学员-------");
                    System.out.println("请输入要修改的学员的学号");
                    studentNum = ClientScanner.getScanner().nextLong();
                    if(queryStudentPrint(studentNum)){
                        System.out.println("请输入修改后的学员的信息,注意无法直接修改学号，修改" +
                                "学号请删除学员后再重新添加新的学员");
                        System.out.println("请输入修改后的姓名");
                        studentName = ClientScanner.getScanner().next();
                        while (true) {
                            System.out.println("请输入修改后的性别,男性请输入1，女性请输入2");
                            int sex = ClientScanner.getScanner().nextInt();
                            if (sex == 1){
                                studentGender = "male";
                                break;
                            }else if (sex == 2){
                                studentGender = "female";
                                break;
                            }else {
                                System.out.println("输入的性别不合法！请重新输入");
                            }
                        }

                        //获取年龄信息，并判断是否合理
                        while(true){
                            System.out.println("请输入修改后的学员年龄");
                            studentAge = ClientScanner.getScanner().nextInt();
                            if (studentAge >= 0 || studentAge <= 140){
                                break;
                            } else {
                                System.out.println("输入年龄信息不合理，请重新输入");
                            }
                        }
                        //获取密码
                        while (true) {
                            System.out.println("请输入密码：");
                            password = ClientScanner.getScanner().next();
                            if (null != password){
                                break;
                            }else {
                                System.out.println("输入的密码为空，请重新输入！");
                            }
                        }
                        newStudent = new Student(studentNum,studentName,studentGender,studentAge,password);
                        //将新增的Student类型的对象发送给服务器端
                        operation = new OperationStudentMessage(newStudent.getStudentNum(),
                                OperationStudentMessage.UPDATE,newStudent);
                        cic.getOos().writeObject(operation);
                        operation = (OperationStudentMessage) cic.getOis().readObject();
                        if ("success".equals(operation.getResult())){
                            System.out.println("修改成功！");
                        }
                    }else {
                        System.out.println("该学号的学员不存在，请确认学号是否有误");
                    }
                    break;

                //查询学员信息
                case 4:
                    System.out.println("-------查询学员-------");
                    System.out.println("请输入要查询的学员的学号");
                    studentNum = ClientScanner.getScanner().nextLong();
                    if (!queryStudentPrint(studentNum)){
                        System.out.println("查询失败，该学号的用户不存在");
                    }
                    break;

                case 5:
                    System.out.println("-------查询所有学员-------");
                    operation = new OperationStudentMessage
                            (studentNum,OperationStudentMessage.GET_ALL_STUDENT);
                    cic.getOos().writeObject(operation);
                    o = cic.getOis().readObject();
                    if (o.getClass() == HashMap.class){
                        studentHashMap = (HashMap)o;
                        Iterator it = studentHashMap.entrySet().iterator();
                        HashMap.Entry<Long,Student> entry = null;
                        if (it.hasNext()){
                            while (it.hasNext()) {
                                entry = (HashMap.Entry<Long,Student>) it.next();
                                System.out.println(entry.getValue().toString());
                            }
                        }else {
                            System.out.println("没有录入过学员哦");
                        }

                    }
                    break;

                default:
                    System.out.println("未输入正确的业务编号！");
            }
        }

    }
    private boolean queryStudentPrint(long Num) throws IOException, ClassNotFoundException {
            long studentNum = Num;
            //构造OperationStudentMessage类型的对象将其写入对象输出流中
            OperationStudentMessage operation = new OperationStudentMessage
                    (studentNum,OperationStudentMessage.QUERY);
            cic.getOos().writeObject(operation);
            Object o = cic.getOis().readObject();
            if (o.getClass() == OperationStudentMessage.class){
                operation = (OperationStudentMessage)o;
                if ("success".equals(operation.getResult()) && null != operation.getStudent()){
                    System.out.println("该学员的信息为：" + operation.getStudent().toString());
                    return true;
                }else if ("无此用户".equals(operation.getResult())){
                    return false;
                }
            }
            return false;


    }

    private void manageExamQuestion() throws IOException, ClassNotFoundException {
        Object o;
        int choose = 0;
        ChoiceQuestion choiceQuestion = null;
        OperationQuestionMessage oqm = null;
        int num = 0;
        String question;
        String choice;
        String choices = "";
        String answer;
        HashMap<Integer,ChoiceQuestion> choiceQuestionHashMap;
        //打印功能列表
        boolean flag = true;
        while (flag){
            System.out.println("\t\t在线考试系统学员管理");
            System.out.println("-------------------------------------------");
            System.out.print("   [1] 新增题目");
            System.out.print("   [2] 删除题目");
            System.out.print("   [3] 修改题目");
            System.out.print("   [4] 查找题目");
            System.out.print("   [5] 显示所有题目");
            System.out.println("   [0] 退出子系统");
            System.out.println("-------------------------------------------");
            System.out.println("请选择要进行的业务编号：");
            choose = ClientScanner.getScanner().nextInt();
            switch (choose){
                case 0:
                    System.out.println("正在退出学员管理子系统......");
                    flag = false;
                    break;
                    //增加考题
                case 1:
                    while (true){
                        System.out.println("请输入题目的序号,请输入大于0的整数");
                        num = ClientScanner.getScanner().nextInt();
                        if (num > 0)
                            break;
                        else
                            System.out.println("输入的序号不合法");
                    }
                    if(queryQuestion(num,false)){
                        System.out.println("该序号的问题已存在");
                        break;
                    }
                    System.out.println("请输入选择题的题目");
                    question = ClientScanner.getScanner().next();
                    choices = "";
                    while (true) {
                        System.out.println("请输入选择题的选项,输入所有选项后请输入_exit退出");
                        choice = ClientScanner.getScanner().next();
                        if ("_exit".equals(choice))
                            break;
                        choices = choices + choice + "  ";
                    }
                    System.out.println("请输入选择题的答案");
                    answer = ClientScanner.getScanner().next();

                    choiceQuestion = new ChoiceQuestion(question,choices,answer);
                    oqm = new OperationQuestionMessage(OperationQuestionMessage.ADD,num,choiceQuestion);
                    cic.getOos().writeObject(oqm);
                    o = cic.getOis().readObject();
                    if (o.getClass() == OperationQuestionMessage.class){
                        oqm = (OperationQuestionMessage)o;
                        if("success".equals(oqm.getResult())){
                            System.out.println("题目添加成功");
                        }
                    }
                    break;
                //删除对应题目
                case 2:
                    System.out.println("请输入要删除的题目的编号");
                    num = ClientScanner.getScanner().nextInt();
                    if (queryQuestion(num,true)){
                        oqm = new OperationQuestionMessage(OperationQuestionMessage.DELETE,num);
                        cic.getOos().writeObject(oqm);
                        o = cic.getOis().readObject();
                        if (o.getClass() == OperationQuestionMessage.class){
                            oqm = (OperationQuestionMessage)o;
                            if("success".equals(oqm.getResult())){
                                System.out.println("删除成功");
                            }
                        }
                    }else {
                        System.out.println("删除失败，该序号的问题不存在");
                    }

                    break;

                //修改题目信息
                case 3:
                    System.out.println("请输入要修改的题目编号");
                    num = ClientScanner.getScanner().nextInt();
                    if(queryQuestion(num,true)){
                        System.out.println("请输入选择题的题目");
                        question = ClientScanner.getScanner().next();
                        choices = "";
                        while (true) {
                            System.out.println("请输入选择题的选项,输入所有选项后请输入_exit退出");
                            choice = ClientScanner.getScanner().next();
                            if ("_exit".equals(choice))
                                break;
                            choices = choices + choice + "  ";
                        }
                        System.out.println("请输入选择题的答案");
                        answer = ClientScanner.getScanner().next();

                        choiceQuestion = new ChoiceQuestion(question,choices,answer);
                        oqm = new OperationQuestionMessage(OperationQuestionMessage.ADD,num,choiceQuestion);
                        cic.getOos().writeObject(oqm);
                        o = cic.getOis().readObject();
                        if (o.getClass() == OperationQuestionMessage.class){
                            oqm = (OperationQuestionMessage)o;
                            if("success".equals(oqm.getResult())){
                                System.out.println("题目修改成功");
                            }
                        }
                    }else {
                        System.out.println("查询失败，该序号的问题不存在");
                    }
                    break;

                //查询题目信息
                case 4:
                    System.out.println("请输入要查询的题目的编号");
                    num = ClientScanner.getScanner().nextInt();
                    if(!queryQuestion(num,true)){
                        System.out.println("查询失败，该序号的问题不存在");
                    }
                    break;
                //显示所有题目
                case 5:
                    oqm = new OperationQuestionMessage();
                    cic.getOos().writeObject(oqm);
                    o = cic.getOis().readObject();
                    if (o.getClass() == HashMap.class){
                        choiceQuestionHashMap = (HashMap<Integer,ChoiceQuestion>)o;
                        // 获取值集合的迭代器
                        Iterator it = choiceQuestionHashMap.entrySet().iterator();
                        HashMap.Entry<Integer,ChoiceQuestion> entry = null;
                        if (it.hasNext()){
                            while (it.hasNext()) {
                                entry = (HashMap.Entry<Integer,ChoiceQuestion>) it.next();
                                System.out.println("题目序号:" + entry.getKey());
                                entry.getValue().show();
                            }
                        }else {
                            System.out.println("没有录入过考题哦");
                        }
                    }
                    break;

                default:
                    System.out.println("未输入正确的业务编号！");
            }
        }
    }
    private boolean queryQuestion(int num,boolean isPrintQuestion) throws IOException, ClassNotFoundException {
        OperationQuestionMessage oqm = new
                OperationQuestionMessage(OperationQuestionMessage.QUERY,num);
        cic.getOos().writeObject(oqm);
        Object o = cic.getOis().readObject();
        if (o.getClass() == OperationQuestionMessage.class){
            oqm = (OperationQuestionMessage)o;
            if("success".equals(oqm.getResult())){
                if (isPrintQuestion){
                    System.out.println("查询成功，该题目为：");
                    System.out.println(oqm.getChoiceQuestion().toString());
                    return true;
                }
                return true;
            }
            return false;
        }
        return false;
    }

}
