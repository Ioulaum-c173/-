package com.lagou.server;

import com.lagou.client.ClientInitClose;
import com.lagou.model.ChoiceQuestion;
import com.lagou.model.Student;
import com.lagou.model.User;

import java.io.*;
import java.sql.SQLOutput;
import java.util.HashMap;

/**
 * 编程实现数据的存取
 */
public class ServerDao {

    /**
     * 编程实现管理员账号和密码的校验并将结果返回出去
     * @param user
     * @return
     */
    public boolean serverManagerCheck(User user) {
        if ("admin".equals(user.getUserName()) && "123456".equals(user.getPassword())) {
            return true;
        }
        return false;
    }

    /**
     * 查验学员登录时的信息是否正确
     * @param user
     * @return
     */
    public boolean serverStudentCheck(User user){
        Long studentNum = Long.parseLong(user.getUserName());
        if (ServerInitClose.studentHashMap.containsKey(studentNum)) {
            if (ServerInitClose.studentHashMap.get(studentNum).getPassword().equals(user.getPassword())){
//                System.out.println("studentcheck_校验成功");
                return true;
            }
//            System.out.println("studentcheck_校验失败_密码不正确");
            return false;
        }
//        System.out.println("studentcheck_校验失败_用户不存在");
        return false;
    }

    /**
     * 将修改后的学员信息保存到本地文件中
     * @throws IOException
     */
    public void saveStudentsHashMap() throws IOException {
        ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("./student.txt"));
        System.out.println("正在保存学员数据...");
        oos.writeObject(ServerInitClose.studentHashMap);
    }

    /**
     * 读取本地文件中存储的学生信息
     * @return
     * @throws IOException
     * @throws ClassNotFoundException
     */
    public boolean readStudentsHashMapFile() throws IOException, ClassNotFoundException {
        ObjectInputStream ois = new ObjectInputStream(new FileInputStream("./student.txt"));
        Object o = null;
        try {
            o = ois.readObject();
        } catch (EOFException e) {
            System.out.println("学生信息读取完毕");
        }finally {
            ois.close();
        }
        if (null != o){
            ServerInitClose.studentHashMap = (HashMap<Long, Student>)o;
            return true;
        }else {
            return false;
        }
    }

    /**
     * 查看用来存储学生信息的本地文件是否存在，如果不存在则创建一个
     * @return
     * @throws IOException
     */
    public boolean checkStudentsSaveFileIsExist() throws IOException {
        File file = new File("./student.txt");
        if (!file.exists()){
            file.createNewFile();
            return false;
        }
        return true;
    }

    /**
     * 将问题信息存储到文件中
     * @throws IOException
     */
    public void saveQuestionsHashMap() throws IOException {
        ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("./question.txt"));
        oos.writeObject(ServerInitClose.choiceQuestionHashMap);
    }

    /**
     * 读取本地文件中存储的问题信息
     * @return
     * @throws IOException
     * @throws ClassNotFoundException
     */
    public boolean readQuestionsHashMapFile() throws IOException, ClassNotFoundException {
        ObjectInputStream ois = new ObjectInputStream(new FileInputStream("./question.txt"));
        Object o = null;
        try {
            o = ois.readObject();
        } catch (EOFException e) {
            System.out.println("问题文件读取完成");
        }finally {
            ois.close();
        }
        if (null != o){
            ServerInitClose.choiceQuestionHashMap = (HashMap<Integer, ChoiceQuestion>)o;
            return true;
        }else {
            return false;
        }
    }

    /**
     * 查看用来存储问题的本地文件是否存在，如果不存在则创建一个
     * @return
     * @throws IOException
     */
    public boolean checkQuestionsSaveFileIsExist() throws IOException {
        File file = new File("./question.txt");
        if (!file.exists()){
            file.createNewFile();
            return false;
        }
        return true;
    }
}
