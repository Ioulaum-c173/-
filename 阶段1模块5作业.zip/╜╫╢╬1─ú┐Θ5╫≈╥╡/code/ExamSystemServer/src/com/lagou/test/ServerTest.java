package com.lagou.test;

import com.lagou.model.Student;
import com.lagou.server.Clock;
import com.lagou.server.ServerDao;
import com.lagou.server.ServerInitClose;

import java.io.IOException;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;

public class ServerTest {

    public static void main(String[] args) {
        ServerInitClose sic = null;
        ServerDao sd = null;
        Clock clock = new Clock();
        //从文件中读取学员对象的集合
        HashMap<Long, Student> studentHashMap = new HashMap<>();
        try {
            //声明ServerDao类型的引用指向该类型的对象
            sd = new ServerDao();

            // 1.声明ServerInitClose类型的引用指向该类型的对象
            sic = new ServerInitClose(clock,sd);
            // 2.调用成员方法实现服务器的初始化操作
            sic.serverInit();
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        } finally {
            // 3.调用成员方法实现服务器的关闭操作
            try {
                sd.saveStudentsHashMap();
                sd.saveQuestionsHashMap();
                sic.serverClose();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }


    }
}
