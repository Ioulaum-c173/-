package com.lagou.server;

import com.lagou.client.ClientInitClose;
import com.lagou.model.*;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 *
 */
public class ReciveRunnable implements Runnable {
    private Socket socket;
    private ObjectInputStream ois;
    private ObjectOutputStream oos;
    private Clock clock;
    private ServerDao sd;
    public ReciveRunnable(Socket socket,Clock clock,ServerDao sd) {
        this.socket = socket;
        this.clock = clock;
        this.sd = sd;
    }

    @Override
    public void run() {

        try {
            ois = new ObjectInputStream(socket.getInputStream());
            oos = new ObjectOutputStream(socket.getOutputStream());
            serverReceive();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    /**
     * 自定义成员方法实现客户端发来消息的接收并处理
     */
    public void serverReceive() throws IOException, ClassNotFoundException {
        Object o;
        OperationStudentMessage osm;
        OperationQuestionMessage oqm;
        GetExamQuestionsMessage getExam;
        boolean flag = true;
        //进入无限循环
        while (flag) {
                o = ois.readObject();
                /*
                如果客户端发送的对象是UserMessage类的对象，对传入的登录验证信息进行校验
                并修改UserMessage中的type属性，成功返回success，失败返回fail
                */
                if (o.getClass() == UserMessage.class) {
                    UserMessage tum = (UserMessage)o;
                    System.out.println("接收到的消息是：" + tum);
                    //管理员用户的账号和密码校验
                    if ("managerCheck".equals(tum.getType())){
                        // 调用方法实现管理员账号和密码信息的校验
                        if (sd.serverManagerCheck(tum.getUser())) {
                            tum.setType("success");
                        } else {
                            tum.setType("fail");
                        }
                        //通过ObjectOutputStream对象将修改后的UserMessage类对象返回客户端
                        oos.writeObject(tum);
                        System.out.println("服务器发送登录校验结果成功！");
                    }else if("userCheck".equals(tum.getType())){
                        // 调用方法实现学员账号和密码信息的校验
                        if (sd.serverStudentCheck(tum.getUser())){
                            tum.setType("success");
                        }else {
                            tum.setType("fail");
                        }
                        oos.writeObject(tum);
                        System.out.println("服务器发送登录校验结果成功！");
                        //如果Type值为Logout，说明客户端退出，结束无限循环
                    }else if ("Logout".equals(tum.getType())){
                        ServerInitClose.socketArrayList.remove(socket);
                        socket.close();
                        flag = false;
                    }else {
                        tum.setType("fail");
                    }
                }else if (o.getClass() == GetExamQuestionsMessage.class){
                    //如果服务器端读取出的对象是GetExamQuestionsMessage，说明客户端获取服务器端的题目
                    getExam = (GetExamQuestionsMessage)o;
                    if ("getQuestions".equals(getExam.getMessage())){
                        //如果题库数据少于10道题，向客户端传入所有的题目
                        if (ServerInitClose.choiceQuestionHashMap.size() <= 10 &&
                                ServerInitClose.choiceQuestionHashMap.size() > 0) {
                            getExam.setChoiceQuestionHashMap(ServerInitClose.choiceQuestionHashMap);
                            getExam.setMessage("success");
                        }else {
                            if (null != ServerInitClose.choiceQuestionHashMap){
                                //如果题库数据大于10道，随机传入10道题
                                ArrayList<Integer> arrayList = new ArrayList<>();
                                Iterator it = ServerInitClose.choiceQuestionHashMap.entrySet().iterator();
                                for (Map.Entry<Integer, ChoiceQuestion> entry : ServerInitClose.choiceQuestionHashMap.entrySet()) {
                                    arrayList.add(entry.getKey());
                                }
                                Integer[] keys = arrayList.toArray(new Integer[arrayList.size()]);
                                int[] key = getquestion(keys);
                                for (int k:key){
                                    getExam.getChoiceQuestionHashMap().put(k,ServerInitClose.choiceQuestionHashMap.get(k));
                                    getExam.setMessage("success");
                                }
                            }

                        }
                    }else {
                        getExam.setMessage("file");
                    }
                    oos.writeObject(getExam);
                }else if (o.getClass() == OperationStudentMessage.class){
                    osm = (OperationStudentMessage)o;
                    synchronized (clock){
                        //实现对学生信息的增删改查
                        switch (osm.getOprationType()){
                            case OperationStudentMessage.ADD :
                                    ServerInitClose.studentHashMap.put(osm.getStudentNum(),osm.getStudent());
                                    osm.setResult("success");
                                    oos.writeObject(osm);
                                    oos.reset();
                                    sd.saveStudentsHashMap();
                                break;

                            case OperationStudentMessage.DELETE:
                                if (ServerInitClose.studentHashMap.containsKey(osm.getStudentNum())){
                                    ServerInitClose.studentHashMap.remove(osm.getStudentNum());
                                    osm.setResult("success");
                                    oos.writeObject(osm);
                                    oos.reset();
                                    sd.saveStudentsHashMap();
                                }else {
                                    osm.setResult("无此用户");
                                    oos.writeObject(osm);
                                }
                                break;

                            case OperationStudentMessage.UPDATE:
                                if (ServerInitClose.studentHashMap.containsKey(osm.getStudentNum())){
                                    ServerInitClose.studentHashMap.put(osm.getStudentNum(),osm.getStudent());
                                    osm.setResult("success");
                                    oos.writeObject(osm);
                                    oos.reset();
                                    sd.saveStudentsHashMap();
                                }else {
                                    osm.setResult("无此用户");
                                    oos.writeObject(osm);
                                }
                                break;

                            case OperationStudentMessage.QUERY:
                                if (ServerInitClose.studentHashMap.containsKey(osm.getStudentNum())){
                                    //如果该学号的学生存在，将对应学号的Student类型对象取出存入OperationStudentMessage对象中传回客户端
                                    osm.setStudent(ServerInitClose.studentHashMap.get(osm.getStudentNum()));
                                    osm.setResult("success");
                                    oos.writeObject(osm);
                                    sd.saveStudentsHashMap();
                                }else {
                                    //如果该学号的学生不存在，修改OperationStudentMessage对象中结果并传回客户端
                                    osm.setResult("无此用户");
                                    oos.writeObject(osm);
                                }
                                break;

                            case OperationStudentMessage.GET_ALL_STUDENT:
                                oos.writeObject(ServerInitClose.studentHashMap);
                        }
                    }
                }else if (o.getClass() == OperationQuestionMessage.class){
                    //实现对问题信息的增删改查
                    oqm = (OperationQuestionMessage)o;
                    synchronized (clock){
                        switch (oqm.getOperation()){
                            case OperationQuestionMessage.ADD:
                                ServerInitClose.choiceQuestionHashMap.put(oqm.getNum(),oqm.getChoiceQuestion());
                                oqm.setResult("success");
                                oos.writeObject(oqm);
                                oos.reset();
                                sd.saveQuestionsHashMap();
                                break;
                            case OperationQuestionMessage.DELETE:
                                if (ServerInitClose.choiceQuestionHashMap.containsKey(oqm.getNum())){
                                    ServerInitClose.choiceQuestionHashMap.remove(oqm.getNum());
                                    oqm.setResult("success");
                                    oos.writeObject(oqm);
                                    oos.reset();
                                    sd.saveQuestionsHashMap();
                                }else {
                                    oqm.setResult("无此题目");
                                    oos.writeObject(oqm);
                                }
                                break;
                            case OperationQuestionMessage.UPDATE:
                                if (ServerInitClose.choiceQuestionHashMap.containsKey(oqm.getNum())){
                                    ServerInitClose.choiceQuestionHashMap.remove(oqm.getNum());
                                    ServerInitClose.choiceQuestionHashMap.put(oqm.getNum(),oqm.getChoiceQuestion());
                                    oqm.setResult("success");
                                    oos.writeObject(oqm);
                                    oos.reset();
                                    sd.saveQuestionsHashMap();
                                }else {
                                    oqm.setResult("无此题目");
                                    oos.writeObject(oqm);
                                }
                                break;
                            case OperationQuestionMessage.QUERY:
                                if (ServerInitClose.choiceQuestionHashMap.containsKey(oqm.getNum())){

                                    oqm.setChoiceQuestion(ServerInitClose.choiceQuestionHashMap.get(oqm.getNum()));
                                    oqm.setResult("success");
                                    oos.writeObject(oqm);
                                }else {
                                    //如果该序号的题目不存在，修改OperationQuestionMessage对象中结果并传回客户端
                                    oqm.setResult("无此题目");
                                    oos.writeObject(oqm);
                                }
                                break;

                            case OperationQuestionMessage.GET_ALL_QUESTIONS:
                                oos.writeObject(ServerInitClose.choiceQuestionHashMap);
                                break;
                        }
                    }
                }

        }


    }

    private int[] getquestion(Integer[] numbers){
        int[] results = new int[10];
        int n = numbers.length;
        for (int i = 0; i < results.length; i++){
            // 取出一个随机数
            int r = (int) (Math.random() * n);

            results[i] = numbers[r];

            // 排除已经取过的值
            numbers[r] = numbers[n - 1];

            n--;

        }
        return results;
    }
}
