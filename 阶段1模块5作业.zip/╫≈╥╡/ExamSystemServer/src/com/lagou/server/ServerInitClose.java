package com.lagou.server;

import com.lagou.model.ChoiceQuestion;
import com.lagou.model.Student;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;

/**
 * 编程实现服务器的初始化和关闭
 */
public class ServerInitClose {
    static {
        studentHashMap = new HashMap<>();
        choiceQuestionHashMap = new HashMap<>();
    }
    /**
     * 自定义成员变量来记录Socket和流对象
     */
    public static HashMap<Long, Student> studentHashMap;
    public static HashMap<Integer, ChoiceQuestion> choiceQuestionHashMap;
    public static ArrayList<Socket> socketArrayList = new ArrayList<>();
    private ServerSocket ss;
    private Socket socket;
    private Clock clock;
    private ServerDao sd;

    public ServerInitClose(Clock clock,ServerDao sd) {
        this.clock = clock;
        this.sd = sd;
    }

    /**
     * 自定义成员方法实现服务器的初始化操作
     */
    public void serverInit() throws IOException, ClassNotFoundException {
        initHashMap();

        // 1.创建ServerSocket类型的对象并提供端口号
        ss = new ServerSocket(8888);
        // 2.等待客户端的连接请求，调用accept方法
        System.out.println("等待客户端的连接请求...");
        while (true) {
            socket = ss.accept();
            socketArrayList.add(socket);
            //每多一个客户端连接服务器，就新开一个线程来处理这个客户端的各种访问请求
            new Thread(new ReciveRunnable(socket,clock,sd)).start();
        }


    }

    private void initHashMap() throws IOException, ClassNotFoundException {
        //初始化保存学生对象的HashMap和保存题目对象的HashMap
        //调用ServerDao类型对象的成员方法判断文件是否存在，不存在则创建
        if(sd.checkStudentsSaveFileIsExist()){
            //文件存在则读取文件中的HashMap对象,key值为学号，value为对应学号的Student对象
            if (sd.readStudentsHashMapFile()){
                if (null == studentHashMap){
                    studentHashMap = new HashMap<>();
                }
            }
            System.out.println("学生数据读取成功");
        }

        if (sd.checkQuestionsSaveFileIsExist()){
            if (sd.readQuestionsHashMapFile()){
                if (null == choiceQuestionHashMap) {
                    choiceQuestionHashMap = new HashMap<>();
                }
            }
            System.out.println("题目数据读取成功");
        }
    }

    /**
     * 自定义成员方法实现服务器的关闭操作
     */
    public void serverClose() throws IOException {
        // 4.关闭Socket并释放有关的资源
        socket.close();
        ss.close();
        System.out.println("服务器成功关闭！");
    }
}
