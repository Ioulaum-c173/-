package com.lagou.model;

import java.io.Serializable;

public class OperationQuestionMessage implements Serializable {
    private static final long serialVersionUID = 3618673479394238841L;
    public static final int ADD = 1;
    public static final int DELETE = 2;
    public static final int UPDATE = 3;
    public static final int QUERY = 4;
    public static final int GET_ALL_QUESTIONS = 5;
    //int成员变量，代表对题目的操作方式
    private int operation;
    //int成员变量，代表题目的序号
    private int num;
    //选择题的对象作为成员变量一起传进来
    private ChoiceQuestion choiceQuestion;
    //服务器端操作的结果
    private String result;

    public OperationQuestionMessage(int operation, int num, ChoiceQuestion choiceQuestion) {
        this.operation = operation;
        this.num = num;
        this.choiceQuestion = choiceQuestion;
    }

    public OperationQuestionMessage(int operation, int num) {
        this.operation = operation;
        this.num = num;
    }

    public OperationQuestionMessage() {
        this.operation = GET_ALL_QUESTIONS;
    }


    public int getOperation() {
        return operation;
    }

    public void setOperation(int operation) {
        this.operation = operation;
    }

    public int getNum() {
        return num;
    }

    public void setNum(int num) {
        this.num = num;
    }

    public ChoiceQuestion getChoiceQuestion() {
        return choiceQuestion;
    }

    public void setChoiceQuestion(ChoiceQuestion choiceQuestion) {
        this.choiceQuestion = choiceQuestion;
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }
}
