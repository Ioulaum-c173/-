package com.lagou.model;

import java.io.Serializable;

public class OperationStudentMessage implements Serializable {
    private static final long serialVersionUID = 257267457907522308L;
    public static final int ADD = 1;
    public static final int DELETE = 2;
    public static final int UPDATE = 3;
    public static final int QUERY = 4;
    public static final int GET_ALL_STUDENT = 5;

    private long studentNum;
    private int oprationType;
    private Student student;
    private String result;

    public OperationStudentMessage(long studentNum,int oprationType,Student student) {
        this.studentNum = studentNum;
        this.oprationType = oprationType;
        this.student = student;
    }

    public OperationStudentMessage(long studentNum, int oprationType) {
        this.studentNum = studentNum;
        this.oprationType = oprationType;
    }

    public long getStudentNum() {
        return studentNum;
    }

    public int getOprationType() {
        return oprationType;
    }

    public Student getStudent() {
        return student;
    }

    public void setStudent(Student student) {
        this.student = student;
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }
}
