package com.lagou.model;

public class Grands {
    private Long studentNum;
    private int totalGrand;
    private double grand;
    private String time;

    public Grands(Long studentNum, int totalGrand, double grand, String time) {
        this.studentNum = studentNum;
        this.totalGrand = totalGrand;
        this.grand = grand;
        this.time = time;
    }

    public Long getStudentNum() {
        return studentNum;
    }

    public void setStudentNum(Long studentNum) {
        this.studentNum = studentNum;
    }

    public int getTotalGrand() {
        return totalGrand;
    }

    public double getGrand() {
        return grand;
    }

    public void setGrand(double grand) {
        this.grand = grand;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    @Override
    public String toString() {
        return "grands{" +
                "studentNum=" + studentNum +
                ", grand=" + grand +
                ", time='" + time + '\'' +
                '}';
    }

    public String show(){
        return "学号：" + studentNum +
                ",     满分：" + totalGrand +
                ",     成绩：" + grand +
                ",     时间：" + time +
                "";
    }
}
