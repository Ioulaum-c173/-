package com.lagou.model;

import java.io.Serializable;

public class Student implements Serializable {
    private static final long serialVersionUID = 4462502010776815527L;

    private long studentNum;
    private String studentName;
    private String studentGender;
    private int studentAge;
    private String password;

    public Student(long studentNum, String studentName, String studentGender, int studentAge, String password) {
        this.studentNum = studentNum;
        this.studentName = studentName;
        this.studentGender = studentGender;
        this.studentAge = studentAge;
        this.password = password;
    }


    public long getStudentNum() {
        return studentNum;
    }

    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public String getStudentGender() {
        return studentGender;
    }

    public void setStudentGender(String studentGender) {
        this.studentGender = studentGender;
    }

    public int getStudentAge() {
        return studentAge;
    }

    public void setStudentAge(int studentAge) {
        this.studentAge = studentAge;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Override
    public String toString() {
        return "Student{" +
                "studentNum=" + studentNum +
                ", studentName='" + studentName + '\'' +
                ", studentGender='" + studentGender + '\'' +
                ", studentAge=" + studentAge +
                ", password='" + password + '\'' +
                '}';
    }
}
